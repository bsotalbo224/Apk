import 'package:flutter/material.dart';

class AnimeDetailScreen extends StatelessWidget {
  final String title;

  AnimeDetailScreen({required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title), backgroundColor: Colors.red),
      body: Center(
        child: Text(
          "Details for $title",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}