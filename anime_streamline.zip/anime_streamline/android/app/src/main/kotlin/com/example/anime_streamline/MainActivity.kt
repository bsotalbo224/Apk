package com.example.anime_streamline

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
